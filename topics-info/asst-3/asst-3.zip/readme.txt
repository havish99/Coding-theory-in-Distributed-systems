The input parameters in soln.py can be suitably modified.

The plot consists of number of workers vs time taken(in seconds).